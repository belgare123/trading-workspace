/**
 * Quick connectivity test for Bybit TestNet
 * Tests: server time, account info, balance, positions, open orders
 */
const crypto = require('crypto')
const API_KEY = process.env.BYBIT_TESTNET_API_KEY
const API_SECRET = process.env.BYBIT_TESTNET_API_SECRET
const BASE = 'https://api-testnet.bybit.com'

async function signAndSend(method, path, params = {}) {
  const timestamp = Date.now().toString()
  const recvWindow = '5000'
  let queryString = ''
  let bodyStr = ''
  if (method === 'GET') {
    queryString = new URLSearchParams(params).toString()
  } else {
    bodyStr = JSON.stringify(params)
  }
  const signPayload = timestamp + API_KEY + recvWindow + (method === 'GET' ? queryString : bodyStr)
  const signature = crypto.createHmac('sha256', API_SECRET).update(signPayload).digest('hex')
  const url = BASE + path + (queryString ? '?' + queryString : '')
  const res = await fetch(url, {
    method,
    headers: {
      'X-BAPI-API-KEY': API_KEY,
      'X-BAPI-TIMESTAMP': timestamp,
      'X-BAPI-SIGN': signature,
      'X-BAPI-RECV-WINDOW': recvWindow,
      'Content-Type': 'application/json',
    },
    ...(method === 'POST' ? { body: bodyStr } : {}),
  })
  return res.json()
}

async function main() {
  const info = await signAndSend('GET', '/v5/account/info')
  if (info.retCode !== 0) { console.error('ACCOUNT INFO FAILED:', JSON.stringify(info)); return }
  console.log('✅ Account info:', info.result.unifiedMarginStatus ? 'Unified' : 'Classic')

  const bal = await signAndSend('GET', '/v5/account/wallet-balance', { accountType: 'UNIFIED', coin: 'USDT' })
  if (bal.retCode !== 0) { console.error('BALANCE FAILED:', JSON.stringify(bal)); return }
  if (bal.result?.list?.[0]) {
    const usdt = bal.result.list[0].coin.find(c => c.coin === 'USDT')
    console.log(`✅ Balance: wallet=${usdt?.walletBalance}, equity=${usdt?.equity}, available=${usdt?.availableToWithdraw}`)
  } else {
    console.log('✅ Balance: empty (no USDT)')
  }

  const pos = await signAndSend('GET', '/v5/position/list', { category: 'linear', settleCoin: 'USDT' })
  if (pos.retCode !== 0) { console.error('POSITIONS FAILED:', JSON.stringify(pos)); return }
  const posList = pos.result?.list || []
  console.log(`✅ Positions: ${posList.length} open`)

  const ord = await signAndSend('GET', '/v5/order/realtime', { category: 'linear', settleCoin: 'USDT' })
  if (ord.retCode !== 0) { console.error('ORDERS FAILED:', JSON.stringify(ord)); return }
  const ordList = ord.result?.list || []
  console.log(`✅ Open orders: ${ordList.length}`)

  // Step 5: Get BTCUSDT market price
  console.log('\n=== Market price (BTCUSDT) ===')
  const ticker = await (await fetch(BASE + '/v5/market/tickers?category=linear&symbol=BTCUSDT')).json()
  if (ticker.retCode !== 0) { console.error('TICKER FAILED:', JSON.stringify(ticker)); return }
  const lastPrice = parseFloat(ticker.result.list[0].lastPrice)
  console.log(`✅ BTCUSDT: ${lastPrice}`)

  // Step 6: Place a small limit order far below market (won't fill)
  console.log('\n=== Place LIMIT order (BTCUSDT) ===')
  const placed = await signAndSend('POST', '/v5/order/create', {
    category: 'linear',
    symbol: 'BTCUSDT',
    side: 'Buy',
    orderType: 'Limit',
    qty: '0.001',
    price: (lastPrice * 0.9).toFixed(1),
    timeInForce: 'GTC',
    orderLinkId: `test-${Date.now()}`,
  })
  if (placed.retCode !== 0) { console.error('ORDER PLACE FAILED:', JSON.stringify(placed)); return }
  console.log(`✅ Order placed: id=${placed.result.orderId}, linkId=${placed.result.orderLinkId}`)

  // Step 7: Cancel the order
  console.log('\n=== Cancel order ===')
  const cancelled = await signAndSend('POST', '/v5/order/cancel', {
    category: 'linear',
    symbol: 'BTCUSDT',
    orderId: placed.result.orderId,
  })
  if (cancelled.retCode !== 0) { console.error('ORDER CANCEL FAILED:', JSON.stringify(cancelled)); return }
  console.log(`✅ Order cancelled: id=${cancelled.result.orderId}`)

  console.log('\n🎉 All REST endpoints verified — full round-trip PASS!')
}
main().catch(console.error)
