const os = require('os');
const fs = require('fs');
const path = require('path');
const f = path.join(os.tmpdir(), 'paper-campaign', 'state.json');
if (fs.existsSync(f)) {
  const d = JSON.parse(fs.readFileSync(f, 'utf8'));
  const stat = fs.statSync(f);
  console.log('mtime:', new Date(stat.mtime).toISOString());
  console.log('now:', new Date().toISOString());
  console.log('uptime:', d.uptime);
  // Estimated daemon start time from uptime
  const uptimeMin = parseInt(d.uptime);
  const estimatedStart = new Date(stat.mtimeMs - uptimeMin * 60 * 1000);
  console.log('est start from uptime:', estimatedStart.toISOString());
  // Read daemon log to see when certification ran
  const certTimestamp = d.lastCertTimestamp;
  console.log('cert timestamp:', certTimestamp);
}
