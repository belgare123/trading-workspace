# Plugin Manifest

> **Source:** `runtime/Manifest.ts`

The manifest is a JSON file that declares plugin metadata, capabilities, and dependencies.

```json
{
  "id": "my-plugin",
  "name": "My Plugin",
  "version": "1.0.0",
  "description": "What this plugin does",
  "author": "Plugin Author",
  "icon": "bar-chart",
  "permissions": ["market.read", "widget.write"],
  "dependencies": {
    "runtime": ">=2.0.0",
    "other-plugin": "^1.0.0"
  },
  "widgets": ["my-widget-id"],
  "commands": ["my-command-id"],
  "searchAdapters": ["my-search-adapter"]
}
```

# Plugin Lifecycle

> **Source:** `runtime/PluginLoader.ts`

```
installed → validated → loaded → activated → ready
                                    ↓
                               sleeping → ready
                        ↓
                   deactivated → unloaded → removed
```

## States

| State | Description |
|-------|-------------|
| `installed` | Manifest registered in PluginLoader |
| `validated` | Manifest, capabilities, dependencies checked |
| `loaded` | Code executed (`register()` called) |
| `activated` | Plugin activated but not fully ready |
| `ready` | Plugin fully operational |
| `sleeping` | Temporarily disabled |
| `deactivated` | Disabled |
| `unloaded` | Code cleanup (`unregister()` called) |
| `removed` | Fully removed |
| `error` | Failed state, can recover to installed |

## Usage

```typescript
import { PluginLoader } from '../runtime/PluginLoader'

// Install
PluginLoader.install({
  manifest: { id: 'my-plugin', version: '1.0.0', ... },
  register: (ctx) => { ... },
  unregister: () => { ... },
})

// Full lifecycle in one step
PluginLoader.loadAndActivate(package)

// Remove
PluginLoader.unloadAndRemove('my-plugin')

// Query
const state = PluginLoader.state('my-plugin')
const loaded = PluginLoader.loaded()
```

# Capabilities

> **Source:** `runtime/Capabilities.ts`

## Standard Capabilities

| Capability | Description |
|-----------|-------------|
| `market.read` | Subscribe to market data |
| `market.write` | Place orders |
| `widget.write` | Register widgets |
| `command.execute` | Register commands |
| `notification.write` | Send notifications |
| `ml.read` | Read ML models/predictions |
| `ml.write` | Train/update ML models |
| `search.index` | Contribute search results |
| `event.read` | Read event history |
| `event.write` | Emit custom events |
| `plugin.install` | Install other plugins |

```typescript
capabilityRegistry.check('my-plugin', ['market.read', 'widget.write'])
```
