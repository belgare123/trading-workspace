/**
 * Data types for Dashboard DataProviders.
 * Each provider defines its output shape.
 */

// ── KPI Strip ──
export interface KpiData {
  equity: number
  pnlDaily: number
  pnlTotal: number
  openPositions: number
  winRate: number
  activeStrategies: number
  runtimeHealth: number
}

// ── Market Overview ──
export interface MarketAsset {
  symbol: string
  price: number
  change24h: number
  volume: number
  high24h: number
  low24h: number
}

export interface MarketOverviewData {
  assets: MarketAsset[]
  lastUpdate: number
}

// ── Live Signals ──
export type SignalDirection = 'LONG' | 'SHORT'
export type SignalStatus = 'active' | 'executed' | 'expired' | 'cancelled'

export interface SignalItem {
  id: string
  symbol: string
  direction: SignalDirection
  confidence: number
  price: number
  reason: string
  model: string
  timestamp: number
  status: SignalStatus
}

export interface LiveSignalsData {
  signals: SignalItem[]
  total: number
}

// ── Portfolio Snapshot ──
export interface PortfolioAllocation {
  symbol: string
  percentage: number
  pnlUnrealized: number
}

export interface PortfolioSnapshotData {
  balance: number
  exposure: number
  leverage: number
  pnlDaily: number
  pnlTotal: number
  risk: number
  drawdown: number
  allocations: PortfolioAllocation[]
}

// ── Opportunities ──
export interface OpportunityItem {
  id: string
  type: 'arbitrage' | 'momentum' | 'divergence' | 'signal'
  symbol: string
  direction: SignalDirection
  confidence: number
  potentialProfit: number
  timestamp: number
}

export interface OpportunitiesData {
  opportunities: OpportunityItem[]
}

// ── Strategy Status ──
export interface StrategyInfo {
  id: string
  name: string
  status: 'running' | 'paused' | 'error' | 'disabled'
  signals: number
  profit: number
  sharpe: number
  winrate: number
  cpu: number
  latency: number
  eventsPerSec: number
}

export interface StrategyStatusData {
  strategies: StrategyInfo[]
}

// ── Runtime Health ──
export interface ServiceHealth {
  name: string
  status: 'healthy' | 'degraded' | 'down'
  uptime: number
  latency: number
}

export interface RuntimeHealthData {
  services: ServiceHealth[]
  pluginsActive: number
  pluginsTotal: number
  eventThroughput: number
  memoryUsage: number
}

// ── Timeline ──
export interface TimelineEntry {
  id: string
  topic: string
  summary: string
  type: 'market' | 'signal' | 'system' | 'trade'
  timestamp: number
}

export interface TimelineData {
  entries: TimelineEntry[]
}

// ── Notifications ──
export interface NotificationItem {
  id: string
  severity: 'info' | 'warning' | 'error' | 'critical'
  title: string
  message: string
  timestamp: number
  read: boolean
}

export interface NotificationsData {
  notifications: NotificationItem[]
  unread: number
}
