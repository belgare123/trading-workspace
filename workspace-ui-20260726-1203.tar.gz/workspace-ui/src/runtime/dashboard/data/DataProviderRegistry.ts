import { Registry } from '../../Registry'
import type { RuntimeApi } from '../../types'

/**
 * WidgetDataProvider — separates data fetching from UI rendering.
 *
 * A provider subscribes to Runtime Services and emits typed data.
 * Widget components use this via the DataProviderRegistry without
 * knowing how data is fetched.
 *
 * One provider can be reused across Workspace, Trading Lab, Mobile.
 */
export interface WidgetDataProvider<T = unknown> {
  /** Unique provider ID (matches a widget's data dependency) */
  readonly id: string

  /**
   * Subscribe to real-time data.
   *
   * @param runtime  — RuntimeApi for service access
   * @param callback — called with fresh data on every change
   * @returns        — unsubscribe function
   */
  subscribe(runtime: RuntimeApi, callback: (data: T) => void): () => void
}

/**
 * DataProviderRegistry — singleton registry for WidgetDataProviders.
 *
 * Extends Registry<WidgetDataProvider> with a typed `get` for
 * convenient use in hooks.
 */
class DataProviderRegistryClass extends Registry<WidgetDataProvider> {
  /** Typed lookup — returns WidgetDataProvider<T> scoped to the expected type. */
  get<T = unknown>(id: string): WidgetDataProvider<T> | undefined {
    return super.get(id) as WidgetDataProvider<T> | undefined
  }
}

/** Global singleton */
export const DataProviderRegistry = new DataProviderRegistryClass()
