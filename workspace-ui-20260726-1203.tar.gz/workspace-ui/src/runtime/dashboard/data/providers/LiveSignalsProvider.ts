import type { WidgetDataProvider } from '../DataProviderRegistry'
import type { RuntimeApi } from '../../../types'
import type { LiveSignalsData, SignalItem } from '../types'

let signalCounter = 0

const SIGNAL_REASONS = [
  'RSI divergence detected',
  'MACD crossover bullish',
  'Volume spike above 3σ',
  'Order book imbalance',
  'ML ensemble consensus',
  'Support level bounce',
  'Breakout above resistance',
  'Funding rate reversal',
]

const MODELS = ['transformer-v2', 'xgboost-v4', 'lstm-attn', 'ensemble-rf']

export const liveSignalsProvider: WidgetDataProvider<LiveSignalsData> = {
  id: 'live-signals',

  subscribe(runtime: RuntimeApi, callback: (data: LiveSignalsData) => void): () => void {
    const signals: SignalItem[] = []

    // Seed some signals
    for (let i = 0; i < 3; i++) {
      signals.push(generateSignal())
    }
    callback({ signals, total: signals.length })

    const unsubEvent = runtime.events.on('strategy.signal' as never, () => {
      signals.unshift(generateSignal())
      if (signals.length > 50) signals.length = 50
      callback({ signals, total: signals.length })
    })

    // Simulate new signals periodically
    const interval = setInterval(() => {
      signals.unshift(generateSignal())
      if (signals.length > 50) signals.length = 50
      callback({ signals, total: signals.length })
    }, 12000)

    return () => {
      unsubEvent()
      clearInterval(interval)
    }
  },
}

function generateSignal(): SignalItem {
  const dir = Math.random() > 0.5 ? 'LONG' : 'SHORT'
  const confidence = 60 + Math.random() * 38
  const symbols = ['BTC', 'ETH', 'SOL', 'AVAX', 'LINK', 'DOGE']
  signalCounter++
  return {
    id: `sig-${signalCounter}-${Date.now()}`,
    symbol: symbols[Math.floor(Math.random() * symbols.length)],
    direction: dir,
    confidence: Math.round(confidence * 10) / 10,
    price: 50000 + Math.random() * 80000,
    reason: SIGNAL_REASONS[Math.floor(Math.random() * SIGNAL_REASONS.length)],
    model: MODELS[Math.floor(Math.random() * MODELS.length)],
    timestamp: Date.now(),
    status: 'active',
  }
}
