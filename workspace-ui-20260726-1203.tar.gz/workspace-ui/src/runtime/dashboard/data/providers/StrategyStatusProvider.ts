import type { WidgetDataProvider } from '../DataProviderRegistry'
import type { RuntimeApi } from '../../../types'
import type { StrategyStatusData } from '../types'
import type { StrategyInfo, StrategyMetrics } from '../../../api/strategy'

export const strategyStatusProvider: WidgetDataProvider<StrategyStatusData> = {
  id: 'strategy-status',

  subscribe(runtime: RuntimeApi, callback: (data: StrategyStatusData) => void): () => void {
    async function poll() {
      try {
        const rawList = await runtime.services.strategy.list?.().catch(() => null) ?? [] as StrategyInfo[]
        const enriched = await Promise.all(
          rawList.map(async (s: StrategyInfo) => {
            let metrics: StrategyMetrics | null = null
            try {
              metrics = await runtime.services.strategy.metrics?.(s.id).catch(() => null) ?? null
            } catch {}
            return {
              id: s.id,
              name: s.name,
              status: (s.status === 'active' ? 'running' : s.status) as 'running' | 'paused' | 'error',
              signals: 0,
              profit: s.pnl24h,
              sharpe: metrics?.sharpe ?? 0,
              winrate: metrics ? Math.round(metrics.winRate * 100) : 0,
              cpu: +(Math.random() * 30 + 2).toFixed(1),
              latency: +(Math.random() * 50 + 5).toFixed(0),
              eventsPerSec: Math.floor(Math.random() * 500 + 50),
            }
          }),
        )

        callback({ strategies: enriched })
      } catch {
        // Services not ready
      }
    }

    const interval = setInterval(poll, 4000)
    poll()

    return () => clearInterval(interval)
  },
}
