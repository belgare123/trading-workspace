import type { WidgetDataProvider } from '../DataProviderRegistry'
import type { RuntimeApi } from '../../../types'
import type { OpportunitiesData, OpportunityItem } from '../types'

let oppCounter = 0

export const opportunitiesProvider: WidgetDataProvider<OpportunitiesData> = {
  id: 'opportunities',

  subscribe(_runtime: RuntimeApi, callback: (data: OpportunitiesData) => void): () => void {
    const all: OpportunityItem[] = []

    function create(ttl = 5) {
      const types: OpportunityItem['type'][] = ['arbitrage', 'momentum', 'divergence', 'signal']
      const symbols = ['BTC', 'ETH', 'SOL', 'AVAX', 'LINK']
      const dirs: ('LONG' | 'SHORT')[] = ['LONG', 'SHORT']

      for (let i = 0; i < ttl; i++) {
        oppCounter++
        all.push({
          id: `opp-${oppCounter}`,
          type: types[Math.floor(Math.random() * types.length)],
          symbol: symbols[Math.floor(Math.random() * symbols.length)],
          direction: dirs[Math.floor(Math.random() * dirs.length)],
          confidence: +(60 + Math.random() * 38).toFixed(1),
          potentialProfit: +(Math.random() * 5).toFixed(2),
          timestamp: Date.now(),
        })
      }
    }

    create()
    callback({ opportunities: all })

    const interval = setInterval(() => {
      create(Math.floor(Math.random() * 3))
      if (all.length > 20) all.splice(0, all.length - 20)
      callback({ opportunities: all })
    }, 15000)

    return () => clearInterval(interval)
  },
}
