import type { WidgetDataProvider } from '../DataProviderRegistry'
import type { RuntimeApi } from '../../../types'
import type { PortfolioSnapshotData, PortfolioAllocation } from '../types'

export const portfolioSnapshotProvider: WidgetDataProvider<PortfolioSnapshotData> = {
  id: 'portfolio-snapshot',

  subscribe(runtime: RuntimeApi, callback: (data: PortfolioSnapshotData) => void): () => void {
    async function poll() {
      try {
        const [bal, positionsRaw] = await Promise.all([
          runtime.services.portfolio.balance?.().catch(() => null),
          runtime.services.portfolio.positions?.().catch(() => null),
        ])

        const pos: { pair: string; dir: string; size: number; entry: number; mark: number; pnl: number; pnlPercent: number }[] = positionsRaw ?? []
        const totalPnl = pos.reduce((s, p) => s + p.pnl, 0)
        const exposure = pos.reduce((s: number, p: { size: number; mark: number }) => s + p.size * p.mark, 0)
        const allocations: PortfolioAllocation[] = pos.map(p => ({
          symbol: p.pair,
          percentage: exposure > 0 ? ((p.size * p.mark) / exposure) * 100 : 0,
          pnlUnrealized: p.pnl,
        }))

        callback({
          balance: bal?.total ?? 0,
          exposure: Math.round(exposure),
          leverage: exposure > 0 && bal?.total ? +(exposure / bal.total).toFixed(2) : 1,
          pnlDaily: totalPnl,
          pnlTotal: totalPnl,
          risk: +(Math.random() * 8 + 1).toFixed(1),
          drawdown: +(Math.random() * 5).toFixed(2),
          allocations,
        })
      } catch {
        // Services not ready
      }
    }

    const interval = setInterval(poll, 5000)
    poll()

    return () => clearInterval(interval)
  },
}
