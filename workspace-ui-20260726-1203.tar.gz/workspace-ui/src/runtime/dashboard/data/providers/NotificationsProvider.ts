import type { WidgetDataProvider } from '../DataProviderRegistry'
import type { RuntimeApi } from '../../../types'
import type { NotificationsData, NotificationItem } from '../types'

let notifCounter = 0

const SAMPLE_TITLES: { severity: NotificationItem['severity']; title: string; message: string }[] = [
  { severity: 'info', title: 'Strategy started', message: 'MA Cross strategy started on BTCUSDT' },
  { severity: 'warning', title: 'Drawdown threshold', message: 'Portfolio drawdown exceeded 5%' },
  { severity: 'error', title: 'Plugin crashed', message: 'Plugin heatmap-renderer exited with code 1' },
  { severity: 'critical', title: 'Margin call', message: 'BTC margin ratio below 15%' },
  { severity: 'info', title: 'Signal generated', message: 'ML ensemble: LONG BTC, confidence 87%' },
  { severity: 'warning', title: 'Rate limit approaching', message: 'Exchange API usage at 85%' },
  { severity: 'info', title: 'Order filled', message: 'Buy 0.5 BTC @ 118,324.00' },
  { severity: 'error', title: 'WebSocket disconnected', message: 'Binance WebSocket reconnecting (2/5)' },
  { severity: 'info', title: 'Replay session loaded', message: 'Session 2026-07-14 ready for review' },
  { severity: 'warning', title: 'Position concentration', message: 'ETH position is 42% of portfolio' },
]

export const notificationsProvider: WidgetDataProvider<NotificationsData> = {
  id: 'notifications',

  subscribe(runtime: RuntimeApi, callback: (data: NotificationsData) => void): () => void {
    const notifications: NotificationItem[] = []

    // Seed
    for (let i = 0; i < 4; i++) { notifications.push(generateNotif()) }
    callback({ notifications, unread: notifications.filter(n => !n.read).length })

    const unsubEvent = runtime.events.on('notification.*' as never, () => {
      notifications.unshift(generateNotif())
      if (notifications.length > 50) notifications.length = 50
      callback({ notifications, unread: notifications.filter(n => !n.read).length })
    })

    const interval = setInterval(() => {
      notifications.unshift(generateNotif())
      if (notifications.length > 50) notifications.length = 50
      callback({ notifications, unread: notifications.filter(n => !n.read).length })
    }, 18000)

    return () => {
      unsubEvent()
      clearInterval(interval)
    }
  },
}

function generateNotif(): NotificationItem {
  const template = SAMPLE_TITLES[Math.floor(Math.random() * SAMPLE_TITLES.length)]
  notifCounter++
  return {
    id: `notif-${notifCounter}`,
    severity: template.severity,
    title: template.title,
    message: template.message,
    timestamp: Date.now(),
    read: false,
  }
}
