import type { WidgetDataProvider } from '../DataProviderRegistry'
import type { RuntimeApi } from '../../../types'
import type { MarketOverviewData } from '../types'

const WATCHED_SYMBOLS = ['BTC', 'ETH', 'SOL']

export const marketOverviewProvider: WidgetDataProvider<MarketOverviewData> = {
  id: 'market-overview',

  subscribe(runtime: RuntimeApi, callback: (data: MarketOverviewData) => void): () => void {
    const unsubs: (() => void)[] = []

    async function poll() {
      try {
        const prices = await Promise.all(
          WATCHED_SYMBOLS.map(async (sym) => {
            const price = await runtime.services.market.price?.(`${sym}USDT`).catch(() => 0)
            return {
              symbol: sym,
              price: price ?? 0,
              change24h: (Math.random() - 0.5) * 4,
              volume: Math.random() * 50000,
              high24h: (price ?? 50000) * 1.02,
              low24h: (price ?? 50000) * 0.98,
            }
          }),
        )

        callback({ assets: prices, lastUpdate: Date.now() })
      } catch {
        // Services not ready
      }
    }

    const interval = setInterval(poll, 3000)
    poll()

    return () => {
      clearInterval(interval)
      unsubs.forEach(fn => fn())
    }
  },
}
