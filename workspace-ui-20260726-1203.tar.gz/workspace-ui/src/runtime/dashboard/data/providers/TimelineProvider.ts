import type { WidgetDataProvider } from '../DataProviderRegistry'
import type { RuntimeApi } from '../../../types'
import type { TimelineData, TimelineEntry } from '../types'

const ENTRY_SUMMARIES: Record<string, string[]> = {
  market: ['BTC突破$120k', 'ETH反弹至$3,850', 'SOL交易量激增200%', '纳斯达克期货+0.8%', '原油-2.1% 因库存增加'],
  signal: ['LONG BTC — 置信度87%', 'SHORT ETH — ML共识确认', 'LONG SOL — 动量因子触发', 'BTC套利机会 0.32%'],
  system: ['Plugin heatmap-v2 loaded', 'Runtime health check passed', 'Event buffer flushed', 'WebSocket reconnected'],
  trade: ['BTC 0.5 BTC @ $118,200', 'ETH 2.0 ETH @ $3,840', 'SOL 10 SOL @ $142'],
}

const EVENT_TYPES: TimelineEntry['type'][] = ['market', 'signal', 'system', 'trade']

export const timelineProvider: WidgetDataProvider<TimelineData> = {
  id: 'event-timeline',

  subscribe(runtime: RuntimeApi, callback: (data: TimelineData) => void): () => void {
    const entries: TimelineEntry[] = []

    function addEntry() {
      const type = EVENT_TYPES[Math.floor(Math.random() * EVENT_TYPES.length)]
      const summaries = ENTRY_SUMMARIES[type]
      const summary = summaries[Math.floor(Math.random() * summaries.length)]

      entries.unshift({
        id: `evt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        topic: `${type}.${summary.split(' ')[0].toLowerCase()}`,
        summary,
        type,
        timestamp: Date.now(),
      })
      if (entries.length > 30) entries.length = 30
    }

    // Seed initial entries
    for (let i = 0; i < 8; i++) addEntry()
    callback({ entries })

    // Listen to actual runtime events
    const unsubs = [
      runtime.events.on('market.price' as never, () => { addEntry(); callback({ entries }) }),
      runtime.events.on('strategy.signal' as never, () => { addEntry(); callback({ entries }) }),
    ]

    // Periodic simulated events
    const interval = setInterval(() => {
      addEntry()
      callback({ entries })
    }, 8000)

    return () => {
      unsubs.forEach(fn => fn())
      clearInterval(interval)
    }
  },
}
